"""CONTROLADORES del sistema académico.

Los 4 heredan de CrudBase, que YA trae: crear, listar, buscar, obtener,
actualizar, eliminar. Aquí solo se escribe lo propio de cada uno:
  - validar()  -> las reglas del negocio (devuelve un texto de error o None)
  - métodos extra (asignar_docente, agregar_nota, boletin...)
"""
from models_academico import Estudiante, Docente, Materia, Matricula
from views import CrudBase


# ---------------------------------------------------------------------
class EstudianteController(CrudBase):
    MODELO = Estudiante                    # qué clase maneja
    ARCHIVO = "data/estudiantes.json"      # dónde guarda
    NOMBRE = "estudiante"                  # para los mensajes
    CAMPOS_BUSCABLES = ("nombre", "apellido", "email", "carnet")

    def validar(self, datos, id_actual=None):
        # id_actual es None cuando se CREA; trae un id cuando se ACTUALIZA.

        # 1) Campos obligatorios (solo al crear)
        if id_actual is None:
            for campo in self.MODELO.OBLIGATORIOS:
                if not str(datos.get(campo, "")).strip():
                    return f"Falta el campo obligatorio: {campo}"

        # 2) Carnet único
        if "carnet" in datos:
            carnet = str(datos["carnet"]).strip().upper()
            for r in self.registros():
                if r["id"] != id_actual and r["carnet"] == carnet:
                    return f"El carnet {carnet} ya está registrado"
        return None                        # None = todo bien


# ---------------------------------------------------------------------
class DocenteController(CrudBase):
    MODELO = Docente
    ARCHIVO = "data/docentes.json"
    NOMBRE = "docente"
    CAMPOS_BUSCABLES = ("nombre", "apellido", "email", "especialidad")

    def validar(self, datos, id_actual=None):
        # 1) Obligatorios (solo al crear)
        if id_actual is None:
            for campo in self.MODELO.OBLIGATORIOS:
                if not str(datos.get(campo, "")).strip():
                    return f"Falta el campo obligatorio: {campo}"

        # 2) Email único
        if "email" in datos:
            email = str(datos["email"]).strip().lower()
            for r in self.registros():
                if r["id"] != id_actual and r["email"] == email:
                    return "Ese email ya está registrado"
        return None


# ---------------------------------------------------------------------
class MateriaController(CrudBase):
    MODELO = Materia
    ARCHIVO = "data/materias.json"
    NOMBRE = "materia"
    CAMPOS_BUSCABLES = ("nombre", "codigo")

    def __init__(self, docentes=None):
        super().__init__()
        # Necesita al controlador de docentes para comprobar que el docente existe
        self.docentes = docentes or DocenteController()

    def validar(self, datos, id_actual=None):
        # 1) Obligatorios (solo al crear)
        if id_actual is None:
            for campo in self.MODELO.OBLIGATORIOS:
                if not str(datos.get(campo, "")).strip():
                    return f"Falta el campo obligatorio: {campo}"

        # 2) Código único
        if "codigo" in datos:
            codigo = str(datos["codigo"]).strip().upper()
            for r in self.registros():
                if r["id"] != id_actual and r["codigo"] == codigo:
                    return f"El código {codigo} ya está registrado"

        # 3) Si trae docente, ese docente debe existir
        docente_id = str(datos.get("docente_id", "")).strip()
        if docente_id not in ("", "0"):
            if not docente_id.isdigit():
                return "El docente_id debe ser un número"
            if not self.docentes.existe(int(docente_id)):
                return f"No existe un docente con id {docente_id}"
        return None

    def asignar_docente(self, materia_id, docente_id):
        if not self.existe(materia_id):
            return False, "No existe esa materia"
        if not self.docentes.existe(docente_id):
            return False, "No existe ese docente"
        return self.actualizar(materia_id, {"docente_id": docente_id})

    def materias_de_docente(self, docente_id):
        return [m for m in self.listar() if m.docente_id == docente_id]


# ---------------------------------------------------------------------
class MatriculaController(CrudBase):
    MODELO = Matricula
    ARCHIVO = "data/matriculas.json"
    NOMBRE = "matrícula"
    CAMPOS_BUSCABLES = ("periodo",)

    def __init__(self, estudiantes=None, materias=None):
        super().__init__()
        self.estudiantes = estudiantes or EstudianteController()
        self.materias = materias or MateriaController()

    def validar(self, datos, id_actual=None):
        # Al actualizar, `datos` trae solo lo que cambia: se completa con
        # lo que ya estaba guardado para poder validar la matrícula entera.
        if id_actual is None:
            completos = dict(datos)
        else:
            guardado = next(r for r in self.registros() if r["id"] == id_actual)
            completos = {**guardado, **datos}

        estudiante_id = str(completos.get("estudiante_id", "")).strip()
        materia_id = str(completos.get("materia_id", "")).strip()
        periodo = str(completos.get("periodo", "")).strip() or "2026-1"

        # 1) El estudiante debe existir
        if not estudiante_id.isdigit():
            return "El estudiante_id debe ser un número"
        if not self.estudiantes.existe(int(estudiante_id)):
            return f"No existe un estudiante con id {estudiante_id}"

        # 2) La materia debe existir
        if not materia_id.isdigit():
            return "El materia_id debe ser un número"
        if not self.materias.existe(int(materia_id)):
            return f"No existe una materia con id {materia_id}"

        # 3) No repetir: mismo estudiante + misma materia + mismo periodo
        for r in self.registros():
            if (r["id"] != id_actual
                    and r["estudiante_id"] == int(estudiante_id)
                    and r["materia_id"] == int(materia_id)
                    and r["periodo"] == periodo):
                return "Ese estudiante ya está matriculado en esa materia y periodo"
        return None

    def agregar_nota(self, matricula_id, tipo, valor, peso=1):
        """Patrón: obtener -> usar método del objeto -> atrapar error -> guardar."""
        matricula = self.obtener(matricula_id)          # 1. obtener
        if matricula is None:
            return False, "No existe esa matrícula"
        try:
            matricula.agregar_nota(tipo, valor, peso)   # 2. usar su método
        except ValueError as error:                     # 3. la Nota se valida sola
            return False, str(error)

        # 4. guardar. Si no se guarda, la nota se pierde al cerrar el programa.
        registros = self.registros()
        for i, r in enumerate(registros):
            if r["id"] == matricula_id:
                registros[i] = matricula.a_diccionario()
        self._gestor.guardar(registros)
        return True, f"Nota agregada. Promedio: {matricula.promedio} ({matricula.estado})"

    def boletin(self, estudiante_id):
        estudiante = self.estudiantes.obtener(estudiante_id)
        if estudiante is None:
            return None

        lineas = [f"BOLETÍN de {estudiante.nombre_completo}", "-" * 45]
        promedios = []
        for m in self.listar():
            if m.estudiante_id != estudiante_id:
                continue                                 # solo las de este estudiante
            materia = self.materias.obtener(m.materia_id)
            nombre = materia.nombre if materia else "materia eliminada"
            lineas.append(f"{nombre} [{m.periodo}]: {m.promedio} → {m.estado}")
            if m.notas:                                  # ignorar las "Sin notas"
                promedios.append(m.promedio)

        if not promedios:
            lineas.append("Aún no tiene notas.")
        else:
            general = round(sum(promedios) / len(promedios), 2)
            lineas.append("-" * 45)
            lineas.append(f"PROMEDIO GENERAL: {general}")
        return "\n".join(lineas)

    def reprobados(self):
        """Reporte: matrículas reprobadas, junto con su estudiante y materia."""
        resultado = []
        for m in self.listar():
            if m.estado == "Reprobado":
                est = self.estudiantes.obtener(m.estudiante_id)
                mat = self.materias.obtener(m.materia_id)
                resultado.append((m, est, mat))
        return resultado
