# Hoja de estudio — Sistema académico (para el test)

## 1. Los 5 archivos que importan
| Archivo | Para qué sirve | ¿Lo tocarás en el test? |
|---|---|---|
| `models.py` | `ModeloBase` y `Persona` (clases base) | casi nunca |
| `models_academico.py` | Estudiante, Docente, Materia, Nota, Matricula (los **datos y sus reglas**) | **sí**: campos nuevos, reglas de la nota |
| `views.py` | `CrudBase`: el CRUD escrito UNA vez | casi nunca |
| `views_academico.py` | Los 4 controladores (**validar()** + métodos propios) | **sí**: reglas nuevas, reportes |
| `main_academico.py` | Menús | a veces: una opción nueva |

Regla para ubicarte: **¿es una regla del dato?** → modelo. **¿es una regla entre entidades o un reporte?** → controlador. **¿es una opción en pantalla?** → menú.

## 2. Qué pasa cuando creas un estudiante (síguelo con el dedo)
1. `MenuCRUD.crear()` pide los campos de `Estudiante.CAMPOS` → arma un diccionario.
2. Llama a `controlador.crear(datos)` (heredado de `CrudBase`).
3. `crear()` llama a **`validar(datos)`** (abstracto: lo escribe cada controlador). Si devuelve texto → error y se detiene.
4. `crear()` construye `Estudiante(id, **datos)`. Cada **setter** valida (email, carnet…) y lanza `ValueError` si falla.
5. Convierte el objeto con `a_diccionario()` y lo guarda en el JSON con `GestorJSON`.

## 3. Dónde está cada principio (para la parte oral/teórica)
| Principio | Dónde se ve | Frase para decirlo |
|---|---|---|
| **Abstracción** | `ModeloBase` y `CrudBase` (con `@abstractmethod`) | "Definen *qué* debe hacer todo modelo/controlador, sin decir *cómo*; no se pueden instanciar." |
| **Encapsulamiento** | atributos `self.__carnet`, propiedades con `@property` / `setter`; `notas` devuelve una `tuple` | "Los datos son privados y solo se cambian por el setter, que los valida. El objeto no puede nacer inválido." |
| **Herencia** | `Estudiante(Persona)`, `Docente(Persona)`, `super().__init__()` | "Reutilizan nombre, apellido y email de Persona y agregan lo suyo." |
| **Polimorfismo** | `etiqueta()` distinta en cada modelo; `MenuCRUD` sirve para cualquier controlador; `MenuMatriculas` sobrescribe `crear()` | "La misma llamada se comporta distinto según el objeto." |
| **Agregación** | `Materia.docente_id`, `Matricula.estudiante_id/materia_id` | "Solo guardan el id; si se borra la matrícula, el estudiante sigue existiendo." |
| **Composición** | `Matricula` crea sus `Nota` (`agregar_nota`) y las guarda dentro de su JSON | "La nota no existe fuera de su matrícula; si se borra la matrícula, se borran las notas." |

## 4. Modificaciones típicas de examen (todas probadas)

### A. Cambiar la nota de aprobación o la escala — *models_academico.py*
```python
class Matricula(ModeloBase):
    NOTA_APROBACION = 10        # antes 14

class Nota:
    MAXIMA = 10                 # si piden escala 0-10 en vez de 0-20
```

### B. Agregar un tipo de nota — *models_academico.py*
```python
class Nota:
    TIPOS = ("deber", "lección", "examen", "proyecto")
```

### C. Agregar un estado nuevo ("Supletorio") — *models_academico.py*, propiedad `estado`
```python
    @property
    def estado(self):
        if not self.__notas:
            return "Sin notas"
        if self.promedio >= Matricula.NOTA_APROBACION:
            return "Aprobado"
        if self.promedio >= 7:
            return "Supletorio"
        return "Reprobado"
```

### D. Agregar un campo nuevo (ej. `telefono` al Estudiante) — *models_academico.py*
Son **5 lugares**; si olvidas uno falla. Usa esta lista:
```python
class Estudiante(Persona):
    CAMPOS = Persona.CAMPOS + ("carnet", "telefono")          # 1) CAMPOS

    def __init__(self, id_registro, nombre, apellido, email, carnet, telefono=""):  # 2) parámetro
        super().__init__(id_registro, nombre, apellido, email)
        self.carnet = carnet
        self.telefono = telefono                               # 3) asignarlo (pasa por el setter)

    @property                                                  # 4) propiedad + setter con validación
    def telefono(self):
        return self.__telefono

    @telefono.setter
    def telefono(self, valor):
        valor = Estudiante.limpiar(valor)
        if valor and not valor.isdigit():
            raise ValueError("El teléfono solo puede tener números")
        self.__telefono = valor

    def a_diccionario(self):
        datos = super().a_diccionario()
        datos["carnet"] = self.__carnet
        datos["telefono"] = self.__telefono                    # 5) guardarlo en el JSON
        return datos
```
(Si el campo es obligatorio, agrégalo también a `OBLIGATORIOS`.)

### E. Regla nueva en un controlador — *views_academico.py*
"Un docente no puede tener más de 3 materias" (dentro de `MateriaController.validar`, en el bloque del docente):
```python
            otras = [m for m in self.materias_de_docente(int(docente_id))
                     if m.id != id_actual]       # excluye la propia materia al actualizar
            if len(otras) >= 3:
                return "Un docente no puede tener más de 3 materias"
```
**Patrón de toda regla:** recorrer `self.registros()` y `return "mensaje"` si se viola; `return None` si todo bien.

### F. Reporte nuevo — *views_academico.py* (en `MatriculaController`)
```python
    def promedio_de_materia(self, materia_id):
        promedios = [m.promedio for m in self.listar()
                     if m.materia_id == materia_id and m.notas]
        if not promedios:
            return None
        return round(sum(promedios) / len(promedios), 2)
```
Y su opción de menú — *main_academico.py* (en `MenuMatriculas`):
```python
        # en __init__:
        self._opciones["10"] = ("Promedio de una materia", self.ver_promedio_materia)

    def ver_promedio_materia(self):
        materia_id = self.pedir_entero("Id de la materia: ")
        print("Promedio:", self._controlador.promedio_de_materia(materia_id))
        self.pausa()
```

## 5. Errores que suelen pasar en el examen
| Error | Causa | Arreglo |
|---|---|---|
| `AttributeError` al crear | falta `super().__init__(...)` | primera línea del `__init__` del hijo |
| Campo nuevo "no se guarda" | falta en `a_diccionario()` o en `CAMPOS` | revisa los 5 lugares de la receta D |
| Campo nuevo no aparece en el formulario | falta en `CAMPOS` | el menú pide lo que diga `CAMPOS` |
| La nota desaparece al reiniciar | no se volvió a guardar el JSON | `self._gestor.guardar(registros)` |
| Regla de "único" falla al editar | no se excluyó el propio registro | `if r["id"] != id_actual` |
| `TypeError: Can't instantiate abstract class` | falta implementar `validar()` / `etiqueta()` / `a_diccionario()` | impleméntalo en la clase hija |
| Comparar `"3" == 3` | los ids del JSON son `int`, lo tecleado es `str` | convierte con `int(...)` |

## 6. Cómo ejecutar
```
python main_academico.py     # el programa
python test_academico.py     # comprueba todas las reglas
```
