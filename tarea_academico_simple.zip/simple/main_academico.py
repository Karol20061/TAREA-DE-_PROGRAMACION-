"""MENÚS del sistema académico.

MenuCRUD (de main.py) ya sabe hacer crear/listar/buscar/actualizar/eliminar
para CUALQUIER controlador. Solo Matrículas necesita opciones extra.
"""
from main import MenuCRUD
from shared.herramientas import imprimir_titulo, imprimir_error, imprimir_info
from views_academico import (
    EstudianteController, DocenteController,
    MateriaController, MatriculaController,
)


class MenuMatriculas(MenuCRUD):
    """Hereda todo de MenuCRUD y agrega opciones al diccionario _opciones."""

    def __init__(self, controlador):
        super().__init__(controlador, "MATRÍCULAS")
        self._opciones["1"] = ("Matricular estudiante", self.crear)   # reemplaza la 1
        self._opciones["7"] = ("Agregar nota", self.agregar_nota)     # nuevas
        self._opciones["8"] = ("Ver boletín", self.ver_boletin)
        self._opciones["9"] = ("Reporte: reprobados", self.ver_reprobados)

    def crear(self):                       # sobrescribe el crear() del padre
        imprimir_titulo("MATRICULAR ESTUDIANTE")
        for e in self._controlador.estudiantes.listar():
            print(f"  {e}")
        estudiante_id = self.pedir_entero("Id del estudiante: ")
        for m in self._controlador.materias.listar():
            print(f"  {m}")
        materia_id = self.pedir_entero("Id de la materia: ")
        periodo = input("Periodo (Enter = 2026-1): ")

        datos = {"estudiante_id": estudiante_id, "materia_id": materia_id,
                 "periodo": periodo}
        self.mostrar_resultado(*self._controlador.crear(datos))
        self.pausa()

    def agregar_nota(self):
        imprimir_titulo("AGREGAR NOTA")
        matricula_id = self.pedir_entero("Id de la matrícula: ")
        tipo = input("Tipo (deber / lección / examen): ")
        valor = input("Valor (0 a 20): ")
        peso = input("Peso (Enter = 1): ").strip() or 1
        self.mostrar_resultado(
            *self._controlador.agregar_nota(matricula_id, tipo, valor, peso))
        self.pausa()

    def ver_boletin(self):
        imprimir_titulo("BOLETÍN")
        estudiante_id = self.pedir_entero("Id del estudiante: ")
        texto = self._controlador.boletin(estudiante_id)
        print(texto if texto else "No existe ese estudiante")
        self.pausa()

    def ver_reprobados(self):
        imprimir_titulo("REPROBADOS")
        lista = self._controlador.reprobados()
        if not lista:
            imprimir_info("No hay reprobados.")
        for matricula, estudiante, materia in lista:
            print(f"  {estudiante}")         # print usa __str__ -> etiqueta()
            print(f"     {materia}")
            print(f"     {matricula}")
        self.pausa()


class MenuPrincipal:
    def __init__(self):
        # Se crean UNA vez y se comparten (así Materia y Matrícula usan los mismos)
        estudiantes = EstudianteController()
        docentes = DocenteController()
        materias = MateriaController(docentes)
        matriculas = MatriculaController(estudiantes, materias)

        self._menus = {
            "1": MenuCRUD(estudiantes, "ESTUDIANTES"),   # el MISMO menú genérico
            "2": MenuCRUD(docentes, "DOCENTES"),         # con distinto controlador
            "3": MenuCRUD(materias, "MATERIAS"),
            "4": MenuMatriculas(matriculas),
        }

    def ejecutar(self):
        while True:
            imprimir_titulo("SISTEMA ACADÉMICO")
            print("  1. Estudiantes\n  2. Docentes\n  3. Materias\n"
                  "  4. Matrículas\n  0. Salir\n")
            tecla = input("Opción: ").strip()
            if tecla == "0":
                break
            if tecla in self._menus:
                self._menus[tecla].ejecutar()
            else:
                imprimir_error("Opción no válida")


if __name__ == "__main__":
    MenuPrincipal().ejecutar()
